package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet(name = "Query3Servlet", value = "/Query3")
public class Query3Servlet extends HttpServlet {

    @EJB
    Query3Bean Query3Bean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // if user is authenticated

            // get the query1 result list
            ArrayList<ResultModel> query3_list = Query3Bean.getQuery3();

            // set the attribute to get back from the jsp file
            request.setAttribute("query3_list", query3_list);

            // return query1.jsp file
            request.getRequestDispatcher("Query3.jsp").forward(request, response);
    }
}
