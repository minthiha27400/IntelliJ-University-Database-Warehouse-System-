package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet(name = "Query1Servlet", value = "/Query1")
public class Query1Servlet extends HttpServlet {

    @EJB
    Query1Bean Query1Bean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // if user is authenticated

            // get the query1 result list
            ArrayList<ResultModel> query1_list = Query1Bean.getQuery1();

            // set the attribute to get back from the jsp file
            request.setAttribute("query1_list", query1_list);

            // return query1.jsp file
            request.getRequestDispatcher("Query1.jsp").forward(request, response);
    }
}
