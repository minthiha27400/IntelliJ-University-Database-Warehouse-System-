package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query4EJB")
public class Query4Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query4Bean() {
    }

    public ArrayList<ResultModel> getQuery4() {
        String query4 = "SELECT " +
                "l.Lecturer_ID, " +
                "COALESCE(num_courses_taught, 0) AS num_courses_taught " +
                "FROM " +
                "Lecturer l " +
                "LEFT JOIN " +
                "(SELECT Lecturer_ID, COUNT(DISTINCT Course_ID) AS num_courses_taught " +
                "FROM Module " +
                "GROUP BY Lecturer_ID) subq " +
                "ON " +
                "l.Lecturer_ID = subq.Lecturer_ID";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query4);

            ArrayList<ResultModel> query4List = new ArrayList(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query4Model = new ResultModel();
                query4Model.setLecturerID(rs.getLong("LECTURER_ID"));
                query4Model.setNoOfCourseTaught(rs.getLong("NUM_COURSES_TAUGHT"));

                query4List.add(query4Model);
            }

            stmt.close();
            return query4List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}


