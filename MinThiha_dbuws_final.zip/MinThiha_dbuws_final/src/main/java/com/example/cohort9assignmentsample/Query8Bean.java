package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query8EJB")
public class Query8Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query8Bean() {
    }

    public ArrayList<ResultModel> getQuery8() {
        String query8 = "WITH StudentCounts AS (\n" +
                "    SELECT\n" +
                "        e.Academic_year,\n" +
                "        c.Course_Name,\n" +
                "        COUNT(DISTINCT e.Student_ID) AS no_of_students,\n" +
                "        RANK() OVER (PARTITION BY e.Academic_year ORDER BY COUNT(DISTINCT e.Student_ID) DESC) AS student_rank\n" +
                "    FROM\n" +
                "        Enroll e\n" +
                "    JOIN\n" +
                "        Course c ON e.Course_ID = c.Course_ID\n" +
                "    GROUP BY\n" +
                "        e.Academic_year, c.Course_Name\n" +
                ")\n" +
                "SELECT\n" +
                "    Academic_year,\n" +
                "    Course_Name,\n" +
                "    no_of_students\n" +
                "FROM\n" +
                "    StudentCounts\n" +
                "WHERE\n" +
                "    student_rank = 1";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query8);

            ArrayList<ResultModel> query8List = new ArrayList(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query8Model = new ResultModel();
                query8Model.setAcademicYear(rs.getLong("ACADEMIC_YEAR"));
                query8Model.setCourseName(rs.getString("COURSE_NAME"));
                query8Model.setNoOfStudents(rs.getLong("NO_OF_STUDENTS"));

                query8List.add(query8Model);
            }

            stmt.close();
            return query8List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}


