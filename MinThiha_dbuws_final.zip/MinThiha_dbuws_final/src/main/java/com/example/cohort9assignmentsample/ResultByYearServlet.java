package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "ResultByYearServlet", value = "/ResultByYearServlet")
public class ResultByYearServlet extends HttpServlet {

    @EJB
    SessionQueryBean sessionQueryBean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int year = Integer.parseInt(request.getParameter("year"));
//
       ArrayList<Integer> passfailcount =  sessionQueryBean.getSummaryPassFail(year);
//
        request.setAttribute("passcount", passfailcount.get(0));
        request.setAttribute("failcount", passfailcount.get(1));
        request.setAttribute("year", year );

//        // Redirect to a success page or display a success message
      request.getRequestDispatcher("ResultByYear.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

}
