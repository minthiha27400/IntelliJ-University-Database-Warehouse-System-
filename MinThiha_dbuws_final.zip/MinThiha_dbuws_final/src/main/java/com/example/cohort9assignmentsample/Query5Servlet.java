package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet(name = "Query5Servlet", value = "/Query5")
public class Query5Servlet extends HttpServlet {

    @EJB
    Query5Bean Query5Bean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // if user is authenticated

            // get the query1 result list
            ArrayList<ResultModel> query5_list = Query5Bean.getQuery5();

            // set the attribute to get back from the jsp file
            request.setAttribute("query5_list", query5_list);

            // return query1.jsp file
            request.getRequestDispatcher("Query5.jsp").forward(request, response);
    }
}
