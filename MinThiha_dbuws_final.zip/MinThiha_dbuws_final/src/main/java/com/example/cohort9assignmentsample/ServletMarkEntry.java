package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "ServletMarkEntry", value = "/ServletMarkEntry")
public class ServletMarkEntry extends HttpServlet {

    @EJB
    SessionQueryBean sessionQueryBean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
int lecturerid = Integer.parseInt(request.getParameter("lecturerid"));
        int studentid = Integer.parseInt(request.getParameter("sid"));
        int moduleid = Integer.parseInt(request.getParameter("mid"));
        int mark = Integer.parseInt(request.getParameter("mark"));

        String eDateStr = request.getParameter("edate");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date eDate = null;
        try {
            eDate = sdf.parse(eDateStr);
        }catch(Exception e){}

        sessionQueryBean.AddMarkEntry(studentid,moduleid,lecturerid,mark,eDate);
        request.setAttribute("message","Student Mark Entry is success!");
        request.getRequestDispatcher("MarkEntry.jsp").forward(request,response);

    }
}
