package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query5EJB")
public class Query5Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query5Bean() {
    }

    public ArrayList<ResultModel> getQuery5() {
        String query5 = "SELECT " +
                "c.Course_ID, " +
                "TRUNC(AVG(EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM s.DOB))) AS average_Age " +
                "FROM " +
                "Course c " +
                "JOIN " +
                "Enroll e ON c.Course_ID = e.Course_ID " +
                "JOIN " +
                "Student s ON e.Student_ID = s.Student_ID " +
                "GROUP BY " +
                "c.Course_ID";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query5);

            ArrayList<ResultModel> query5List = new ArrayList(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query5Model = new ResultModel();
                query5Model.setCourseID(rs.getLong("COURSE_ID"));
                query5Model.setAverageAge(rs.getLong("AVERAGE_AGE"));

                query5List.add(query5Model);
            }

            stmt.close();
            return query5List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}


