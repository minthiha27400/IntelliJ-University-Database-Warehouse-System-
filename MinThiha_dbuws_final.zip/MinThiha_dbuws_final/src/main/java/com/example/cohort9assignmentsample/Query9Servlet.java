package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet(name = "Query9Servlet", value = "/Query9")
public class Query9Servlet extends HttpServlet {

    @EJB
    Query9Bean Query9Bean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // if user is authenticated

            // get the query1 result list
            ArrayList<ResultModel> query9_list = Query9Bean.getQuery9();

            // set the attribute to get back from the jsp file
            request.setAttribute("query9_list", query9_list);

            // return query1.jsp file
            request.getRequestDispatcher("Query9.jsp").forward(request, response);
    }
}
