package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query2EJB")
public class Query2Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query2Bean() {
    }

    public ArrayList<ResultModel> getQuery2() {
        String query2 = "SELECT " +
                "c.Course_ID, " +
                "COUNT(DISTINCT CASE " +
                "WHEN NOT EXISTS ( " +
                "SELECT 1 " +
                "FROM Marking mk_fail " +
                "WHERE mk_fail.Student_ID = e.Student_ID " +
                "AND mk_fail.Status = 'Fail' " +
                ") THEN e.Student_ID " +
                "ELSE NULL " +
                "END) AS no_of_passed_students " +
                "FROM Course c " +
                "JOIN Module m ON c.Course_ID = m.Course_ID " +
                "JOIN Enroll e ON c.Course_ID = e.Course_ID " +
                "JOIN Marking mk ON e.Student_ID = mk.Student_ID " +
                "GROUP BY c.Course_ID";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query2);

            ArrayList<ResultModel> query2List = new ArrayList(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query2Model = new ResultModel();
                query2Model.setCourseID(rs.getLong("COURSE_ID"));
                query2Model.setNoOfPassedStudents(rs.getLong("NO_OF_PASSED_STUDENTS"));

                query2List.add(query2Model);
            }

            stmt.close();
            return query2List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}


