package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "ServletViewResultModule", value = "/ServletViewResultModule")
public class ServletViewResultModule extends HttpServlet {
    @EJB
    SessionQueryBean sessionQueryBean;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int sid = Integer.parseInt(request.getParameter("sid"));
        //System.out.println("Student Result in View Module Result ************"+sid);
        ArrayList<ResultModel> rmodel = sessionQueryBean.ViewIndividualModuleResult(sid);
        request.setAttribute("rmodel",rmodel);
        request.getRequestDispatcher("ViewModuleResult.jsp").forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
