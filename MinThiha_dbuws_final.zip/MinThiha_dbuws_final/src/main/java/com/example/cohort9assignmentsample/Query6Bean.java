package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query6EJB")
public class Query6Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query6Bean() {
    }

    public ArrayList<ResultModel> getQuery6(String academicYear) { // Accept academic year as a parameter
        String query6 = "SELECT " +
                "e.Academic_year, " +
                "COUNT(DISTINCT CASE " +
                "    WHEN mk.Status IN ('Pass', 'Merit', 'Distinction') THEN e.Student_ID " +
                "    ELSE NULL " +
                "END) AS no_of_passed_students " +
                "FROM " +
                "Enroll e " +
                "JOIN " +
                "Marking mk ON e.Student_ID = mk.Student_ID " +
                "WHERE " +
                "e.Academic_year = " + academicYear +
                "AND e.Student_ID NOT IN ( " +
                "    SELECT DISTINCT e.Student_ID " +
                "    FROM Enroll e " +
                "    JOIN Marking mk ON e.Student_ID = mk.Student_ID " +
                "    WHERE mk.Status IN ('Fail') " +
                ") " +
                "GROUP BY " +
                "e.Academic_year";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query6);

            ArrayList<ResultModel> query6List = new ArrayList<>(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query6Model = new ResultModel();
                query6Model.setAcademicYear(rs.getLong("ACADEMIC_YEAR"));
                query6Model.setNoOfPassedStudents(rs.getLong("NO_OF_PASSED_STUDENTS"));

                query6List.add(query6Model);
            }

            stmt.close();
            return query6List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

}
