package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query3EJB")
public class Query3Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query3Bean() {
    }

    public ArrayList<ResultModel> getQuery3() {
        String query3 = "SELECT " +
                "c.Course_ID, " +
                "COUNT(DISTINCT CASE " +
                "WHEN 'Fail' IN ( " +
                "SELECT mk.Status " +
                "FROM Marking mk " +
                "WHERE mk.Student_ID = e.Student_ID " +
                ") THEN e.Student_ID " +
                "ELSE NULL " +
                "END) AS no_of_failed_students " +
                "FROM Course c " +
                "JOIN Enroll e ON c.Course_ID = e.Course_ID " +
                "GROUP BY c.Course_ID";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query3);

            ArrayList<ResultModel> query3List = new ArrayList(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query3Model = new ResultModel();
                query3Model.setCourseID(rs.getLong("COURSE_ID"));
                query3Model.setNoOfFailedStudents(rs.getLong("NO_OF_FAILED_STUDENTS"));

                query3List.add(query3Model);
            }

            stmt.close();
            return query3List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}


