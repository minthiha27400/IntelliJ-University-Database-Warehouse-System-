package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "ServletLogin", value = "/ServletLogin")
public class ServletLogin extends HttpServlet {
    @EJB
    SessionQueryBean sessionQueryBean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String email = request.getParameter("email");
    String password = request.getParameter("password");

    int found = sessionQueryBean.checkUser(email,password, "student");
    if(found == -1)
    {
        request.setAttribute("message","User is not exist!");
        request.getRequestDispatcher("Login.jsp").forward(request,response);
    }
    else{
        HttpSession session = request.getSession(false);
        session.setAttribute("ID",String.valueOf(found));
        response.sendRedirect("StudentDashboard.jsp");
    }

    }
}