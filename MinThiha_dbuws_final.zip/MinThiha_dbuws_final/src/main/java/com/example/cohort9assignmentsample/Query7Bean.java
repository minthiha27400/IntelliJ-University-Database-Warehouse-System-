package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query7EJB")
public class Query7Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query7Bean() {
    }

    public ArrayList<ResultModel> getQuery7(String academicYear) { // Accept academic year as a parameter
        String query7 = "SELECT " +
                "e.Academic_year, " +
                "COUNT(DISTINCT CASE " +
                "    WHEN mk.Status IN ('Fail') THEN e.Student_ID " +
                "    ELSE NULL " +
                "END) AS no_of_failed_students " +
                "FROM " +
                "Enroll e " +
                "JOIN " +
                "Marking mk ON e.Student_ID = mk.Student_ID " +
                "WHERE " +
                "e.Academic_year =  " + academicYear +
                "GROUP BY " +
                "e.Academic_year";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query7);

            ArrayList<ResultModel> query6List = new ArrayList<>(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query7Model = new ResultModel();
                query7Model.setAcademicYear(rs.getLong("ACADEMIC_YEAR"));
                query7Model.setNoOfFailedStudents(rs.getLong("NO_OF_FAILED_STUDENTS"));

                query6List.add(query7Model);
            }

            stmt.close();
            return query6List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

}
