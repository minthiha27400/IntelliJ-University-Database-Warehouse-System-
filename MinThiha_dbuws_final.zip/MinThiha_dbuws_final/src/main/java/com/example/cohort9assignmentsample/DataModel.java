package com.example.cohort9assignmentsample;

import java.util.Date;

public class DataModel {

    String name; // Use a single "name" field
    String gender;
    String email;
    String phone;
    String address;
    Date dob;
    String[] modules;

    int enrollyear;

    public int getEnrollyear() {
        return enrollyear;
    }

    public void setEnrollyear(int enrollyear) {
        this.enrollyear = enrollyear;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String[] getModules() {
        return modules;
    }

    public void setModules(String[] modules) {
        this.modules = modules;
    }
}
