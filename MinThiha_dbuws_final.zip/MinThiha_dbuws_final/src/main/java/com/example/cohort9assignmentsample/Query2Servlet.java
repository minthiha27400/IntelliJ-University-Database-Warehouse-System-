package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet(name = "Query2Servlet", value = "/Query2")
public class Query2Servlet extends HttpServlet {

    @EJB
    Query2Bean Query2Bean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // if user is authenticated

            // get the query1 result list
            ArrayList<ResultModel> query2_list = Query2Bean.getQuery2();

            // set the attribute to get back from the jsp file
            request.setAttribute("query2_list", query2_list);

            // return query1.jsp file
            request.getRequestDispatcher("Query2.jsp").forward(request, response);
    }
}
