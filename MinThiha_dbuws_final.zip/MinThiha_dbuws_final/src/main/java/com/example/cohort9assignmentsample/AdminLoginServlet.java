package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "AdminLoginServlet", value = "/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    @EJB
    SessionQueryBean sessionQueryBean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String email = request.getParameter("email");
    String password = request.getParameter("password");

    int found = sessionQueryBean.checkUser(email,password, "Admin");
    if(found == -1)
    {
        request.setAttribute("message","User is not exist!");
        request.getRequestDispatcher("Login.jsp").forward(request,response);
    }
    else{
        HttpSession session = request.getSession(false);
        session.setAttribute("ID",String.valueOf(found));
        response.sendRedirect("AdminDashboard.jsp");
    }

    }
}