package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query1EJB")
public class Query1Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query1Bean() {
    }

    public ArrayList<ResultModel> getQuery1() {
        // Query to get the total number of students for each academic year and course ID
        String query = "SELECT " +
                "de.Academic_year, " +
                "de.Course_ID, " +
                "COUNT(de.Student_ID) AS no_of_students " +
                "FROM enroll de " +
                "GROUP BY " +
                "de.Academic_year, de.Course_ID";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            ArrayList<ResultModel> query1List = new ArrayList(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query1Model = new ResultModel();
                query1Model.setAcademicYear(rs.getLong("ACADEMIC_YEAR"));
                query1Model.setCourseID(rs.getLong("COURSE_ID"));
                query1Model.setNoOfStudents(rs.getLong("NO_OF_STUDENTS"));

                query1List.add(query1Model);
            }

            stmt.close();
            return query1List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}


