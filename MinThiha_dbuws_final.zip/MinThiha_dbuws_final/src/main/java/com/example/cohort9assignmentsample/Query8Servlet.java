package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet(name = "Query8Servlet", value = "/Query8")
public class Query8Servlet extends HttpServlet {

    @EJB
    Query8Bean Query8Bean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // if user is authenticated

            // get the query1 result list
            ArrayList<ResultModel> query8_list = Query8Bean.getQuery8();

            // set the attribute to get back from the jsp file
            request.setAttribute("query8_list", query8_list);

            // return query1.jsp file
            request.getRequestDispatcher("Query8.jsp").forward(request, response);
    }
}
