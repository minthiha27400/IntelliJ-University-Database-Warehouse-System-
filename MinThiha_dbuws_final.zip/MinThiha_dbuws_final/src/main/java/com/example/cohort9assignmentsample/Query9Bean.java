package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query9EJB")
public class Query9Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query9Bean() {
    }

    public ArrayList<ResultModel> getQuery9() {
        String query9 = "SELECT " +
                "e.Course_ID, " +
                "e.Academic_year, " +
                "COUNT(CASE WHEN s.Gender = 'Male' THEN 1 END) AS no_of_male_Students, " +
                "COUNT(CASE WHEN s.Gender = 'Female' THEN 1 END) AS no_of_female_Students " +
                "FROM " +
                "Enroll e " +
                "JOIN " +
                "Student s ON e.Student_ID = s.Student_ID " +
                "GROUP BY " +
                "e.Course_ID, e.Academic_year";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query9);

            ArrayList<ResultModel> query9List = new ArrayList(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query9Model = new ResultModel();
                query9Model.setCourseID(rs.getLong("COURSE_ID"));
                query9Model.setNoOfMaleStudents(rs.getLong("no_of_male_Students"));
                query9Model.setNoOfFemaleStudents(rs.getLong("no_of_female_Students"));
                query9List.add(query9Model);
            }

            stmt.close();
            return query9List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}


