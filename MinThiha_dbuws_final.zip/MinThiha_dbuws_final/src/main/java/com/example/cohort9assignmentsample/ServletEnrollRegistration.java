package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "ServletEnrollRegistration", value = "/ServletEnrollRegistration")
public class ServletEnrollRegistration extends HttpServlet {
     @EJB
    SessionQueryBean sessionQueryBean;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String gender = request.getParameter("gender");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");

        int enrollyear = Integer.parseInt(request.getParameter("enrollyear"));

        String startDateStr = request.getParameter("dob");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dob = null;
        try {
            dob = sdf.parse(startDateStr);
        }catch(Exception e){}

        String[] modules =request.getParameterValues("m");



        DataModel dmodel = new DataModel();
        dmodel.setName(name);
        dmodel.setEmail(email);
        dmodel.setGender(gender);
        dmodel.setPhone(phone);
        dmodel.setAddress(address);
        dmodel.setModules(modules);
        dmodel.setDob(dob);
        dmodel.setEnrollyear(enrollyear);

        sessionQueryBean.AddEnrollmentRegistration(dmodel);

        request.setAttribute("message","Enrollment Success!");
        request.getRequestDispatcher("EnrollRegistration.jsp").forward(request,response);



    }
}
