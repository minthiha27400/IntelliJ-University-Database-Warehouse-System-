package com.example.cohort9assignmentsample;

public class ResultModel {
    String name;
    String student_name;

    String course_name;
    String module_code;
    int mark;
    String passfail;
    long academic_year;

    long credits;

    long course_id;

    long lecturer_id;

    long no_of_students;

    long no_of_passed_students;

    long no_of_failed_students;

    long num_courses_taught;

    long average_age;

    long no_of_male_Students;

    long no_of_female_Students;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModule_code() {
        return module_code;
    }

    public void setModule_code(String module_code) {
        this.module_code = module_code;
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }

    public String getPassfail() {
        return passfail;
    }

    public void setPassfail(String passfail) {
        this.passfail = passfail;
    }

    public long getAcademicYear() { return this.academic_year;}
    public void setAcademicYear(long academic_year) {
        this.academic_year = academic_year;
    }

    public long getCourseID() { return this.course_id;}
    public void setCourseID(long course_id) { this.course_id = course_id;}

    public long getLecturerID() { return this.lecturer_id;}

    public void setLecturerID(long lecturer_id) { this.lecturer_id = lecturer_id;}

    public long getNoOfStudents() { return this.no_of_students;}
    public void setNoOfStudents(long no_of_students) {this.no_of_students = no_of_students;}
    public long getNoOfPassedStudents() { return this.no_of_passed_students;}
    public void setNoOfPassedStudents(long no_of_passed_students) {this.no_of_passed_students = no_of_passed_students;}

    public long getNoOfFailedStudents() { return this.no_of_failed_students;}
    public void setNoOfFailedStudents(long no_of_failed_students) {this.no_of_failed_students = no_of_failed_students;}

    public long getNoOfCourseTaught() { return this.num_courses_taught;}
    public void setNoOfCourseTaught(long num_courses_taught) {this.num_courses_taught = num_courses_taught;}

    public long getAverageAge() { return this.average_age;}
    public void setAverageAge(long average_age) {this.average_age = average_age;}

    public long getNoOfMaleStudents() { return this.no_of_male_Students;}

    public void setNoOfMaleStudents(long no_of_male_Students) {this.no_of_male_Students = no_of_male_Students;}
    public long getNoOfFemaleStudents() { return this.no_of_female_Students;}
    public void setNoOfFemaleStudents(long no_of_female_Students) {this.no_of_female_Students = no_of_female_Students;}

    public long getCredits() { return this.credits;}
    public void setCredits(long credits) {this.credits = credits;}

    public String getStudentName() {
        return student_name;
    }
    public void setStudentName(String student_name) {
        this.student_name = student_name;
    }

    public String getCourseName() {
        return course_name;
    }
    public void setCourseName(String course_name) {
        this.course_name = course_name;
    }
}
