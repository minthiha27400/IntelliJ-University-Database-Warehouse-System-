package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

@Stateless(name = "SessionQueryEJB")
public class SessionQueryBean {
    @EJB
    SessionOracleConnectionBean connectionBean;
    public SessionQueryBean() {
    }


    public void AddEnrollmentRegistration(DataModel dmodel) {
        try {
            String key[] = {"Student_ID"};
            Connection connection = connectionBean.getOracleClient();
            String sql = "insert into Student(name, Gender, DOB, email, phone, address ) values(?,?,?,?,?,?)";
            PreparedStatement pstmt = connection.prepareStatement(sql, key);
            pstmt.setString(1, dmodel.getName()); // Use the "name" field
            pstmt.setString(2, dmodel.getGender());
            pstmt.setDate(3, new java.sql.Date(dmodel.getDob().getTime()));
            pstmt.setString(4, dmodel.getEmail());
            pstmt.setString(5, dmodel.getPhone());
            pstmt.setString(6, dmodel.getAddress());

            pstmt.executeUpdate();
            long new_id = -1;
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                new_id = rs.getLong(1);
            }
            String[] marray = dmodel.getModules();
            java.util.Date utilDate = new Date();
            // Convert it to java.sql.Date
            java.sql.Date date = new java.sql.Date(utilDate.getTime());
            for (int i = 0; i < marray.length; i++) {
                sql = "insert into Enroll( Enroll_Date,  Student_ID ,  Module_ID ,  Enroll_year ) values(?,?,?,?)";
                pstmt = connection.prepareStatement(sql);
                pstmt.setDate(1, date);
                pstmt.setLong(2, new_id);
                pstmt.setLong(3, Long.parseLong(marray[i]));
                pstmt.setLong(4, dmodel.getEnrollyear());
                pstmt.executeUpdate();
            }
        } catch (Exception ee) {
            ee.printStackTrace();
        }
    }

    public void AddMarkEntry(int studentid,int moduleid, int lecturerid,int mark, Date edate)
    {
        try{

            Connection connection = connectionBean.getOracleClient();
            String sql = "insert into Marking(MARK_DATE, mark , STUDENT_ID , MODULE_ID , LECTURER_ID) values(?,?,?,?,?)";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setDate(1, new java.sql.Date(edate.getTime()));
            pstmt.setLong(2, mark);
            pstmt.setLong(3, studentid);
            pstmt.setLong(4, moduleid);
            pstmt.setLong(5, lecturerid);

            pstmt.executeUpdate();


        }catch(Exception ee){
            ee.printStackTrace();
        }

    }

    public ArrayList<ResultModel> ViewIndividualModuleResult(int sid)
    {
        ArrayList<ResultModel> rModel = new ArrayList<ResultModel>();
         String sql = "Select * from student where  student_id =?";
         String fname = "";
         String lname = "";
         String email = "";
        try {
            Connection connection = connectionBean.getOracleClient();
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setLong(1, sid);
            ResultSet rs = pstmt.executeQuery();
            if(rs.next())
            {
                fname = rs.getString("FIRST_NAME");
                lname = rs.getString("LAST_NAME");
                email = rs.getString("Email");
            }

            sql = "SELECT a.MODULE_CODE, b.mark " +
                    "from module a inner join marking b " +
                    "on a.module_id = b.module_id " +
                    "where b.student_id = ? " +
                    "order by a.module_code ASC";

            pstmt = connection.prepareStatement(sql);
            pstmt.setLong(1, sid);
            rs = pstmt.executeQuery();
            while(rs.next())
            {
                  ResultModel temp = new ResultModel();
                temp.setName(fname);
                temp.setModule_code(rs.getString("MODULE_CODE"));
                  int temp_mark = rs.getInt("mark");
                  temp.setMark(temp_mark);
                  if(temp_mark >= 40)
                  {
                      temp.setPassfail("Pass");
                  }
                  else{
                      temp.setPassfail("Fail");
                     }

                rModel.add(temp);
            }
    connection.close();
        }catch(Exception e){
            e.printStackTrace();
        }

        return rModel;

    }

    public void Report2()
    {

    }

    public int checkUser(String email, String password, String userType)
    {
        try {
            Connection connection = connectionBean.getOracleClient();
            PreparedStatement pstmt = connection.prepareStatement("Select * from USERLOGIN where email=? and userpassword=? and usertype =?");
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            pstmt.setString(3, userType);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return (int) rs.getLong("USERID");
        }catch(Exception e){
            e.printStackTrace();
        }

        return  -1;
    }

    public int checkLecturer(String email, String password, String userType)
    {
        try {
            Connection connection = connectionBean.getOracleClient();
            PreparedStatement pstmt = connection.prepareStatement("Select * from USERLOGIN where email=? and userpassword=? and usertype =?");
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            pstmt.setString(3, userType);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return (int) rs.getLong("ID");
        }catch(Exception e){
            e.printStackTrace();
        }

        return  -1;
    }

    public ArrayList<Integer> getSummaryPassFail(int year)
    {
        ArrayList<Integer> passfailcount = new ArrayList<Integer>();
        try {
            Connection connection = connectionBean.getOracleClient();
            PreparedStatement pstmt = connection.prepareStatement("Select student_id from Enroll where enroll_year =? ");
            pstmt.setInt(1, year);

            ResultSet rs = pstmt.executeQuery();
            int pass = 0;
            int fail = 0;
            int sid = -1;
            while(rs.next())
            {
                sid = rs.getInt("student_id");
                String  sql = "SELECT mark FROM Marking WHERE student_id = ?";
                PreparedStatement statement = connection.prepareStatement(sql);
                // Set the parameter values
                statement.setInt(1, sid);
                // Execute the query
                ResultSet resultSet = statement.executeQuery();
                String status = "pass";
                while(resultSet.next())
                {
                    if(Integer.parseInt(resultSet.getString("mark")) <40 )  status = "fail";
                }

                if(status.equals("fail")) fail = fail + 1;
                else pass = pass + 1;

            }
            passfailcount.add(pass);
            passfailcount.add(fail);


        }
        catch(Exception e){
            e.printStackTrace();
        }
        return passfailcount;
    }
    
}
