package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet(name = "Query6Servlet", value = "/Query6")
public class Query6Servlet extends HttpServlet {

    @EJB
    Query6Bean Query6Bean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Get the academic year parameter from the request
        String academic_year = request.getParameter("academic_year");


        // if no parameter is found use default value instead
        if(academic_year == null){
            academic_year = "2023";
        }
            // get the query result list
            ArrayList<ResultModel> query6_list = Query6Bean.getQuery6(academic_year);

            // set the attribute to get back from the jsp file
            request.setAttribute("query6_list", query6_list);

            // set the academic_year attribute
            request.setAttribute("academic_year", academic_year);

            // return jsp file
            request.getRequestDispatcher("Query6.jsp").forward(request, response);
        }
    }
