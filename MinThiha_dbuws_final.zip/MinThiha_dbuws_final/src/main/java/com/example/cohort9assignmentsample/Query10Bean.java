package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Stateless(name = "Query10EJB")
public class Query10Bean {

    @EJB
    SessionOracleConnectionBean SessionOracleConnectionBean;

    public Query10Bean() {
    }

    public ArrayList<ResultModel> getQuery10() {
        // Query to get the total number of students for each academic year and course ID
        String query10 = "SELECT\n" +
                "    E.ACADEMIC_YEAR,\n" +
                "    C.COURSE_ID,\n" +
                "    TRUNC(AVG(MK.CREDITS)) AS AVERAGE_CREDITS\n" +
                "FROM\n" +
                "    ENROLL  E\n" +
                "    JOIN COURSE C\n" +
                "    ON E.COURSE_ID = C.COURSE_ID JOIN MODULE M\n" +
                "    ON C.COURSE_ID = M.COURSE_ID\n" +
                "    JOIN MARKING MK\n" +
                "    ON M.MODULE_ID = MK.MODULE_ID\n" +
                "GROUP BY\n" +
                "    E.ACADEMIC_YEAR, C.COURSE_ID\n" +
                "ORDER BY\n" +
                "    E.ACADEMIC_YEAR, C.COURSE_ID";

        Statement stmt = null;

        try {
            Connection con = SessionOracleConnectionBean.getOracleClient();
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query10);

            ArrayList<ResultModel> query10List = new ArrayList(); // Use the correct generic type

            while (rs.next()) {
                ResultModel query10Model = new ResultModel();
                query10Model.setAcademicYear(rs.getLong("ACADEMIC_YEAR"));
                query10Model.setCourseID(rs.getLong("COURSE_ID"));
                query10Model.setCredits(rs.getLong("AVERAGE_CREDITS"));

                query10List.add(query10Model);
            }

            stmt.close();
            return query10List;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}


