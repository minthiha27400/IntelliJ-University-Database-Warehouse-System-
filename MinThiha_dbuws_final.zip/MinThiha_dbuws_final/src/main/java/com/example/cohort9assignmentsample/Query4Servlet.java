package com.example.cohort9assignmentsample;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet(name = "Query4Servlet", value = "/Query4")
public class Query4Servlet extends HttpServlet {

    @EJB
    Query4Bean Query4Bean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // if user is authenticated

            // get the query1 result list
            ArrayList<ResultModel> query4_list = Query4Bean.getQuery4();

            // set the attribute to get back from the jsp file
            request.setAttribute("query4_list", query4_list);

            // return query1.jsp file
            request.getRequestDispatcher("Query4.jsp").forward(request, response);
    }
}
