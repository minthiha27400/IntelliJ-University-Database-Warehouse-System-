package com.example.cohort9assignmentsample;

import javax.ejb.Singleton;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.pool.OracleDataSource;

import javax.ejb.*;
import java.sql.*;
import javax.annotation.PostConstruct;

@Singleton(name = "SessionOracleConnectionEJB")
public class SessionOracleConnectionBean {

    final static String DB_URL="jdbc:oracle:thin:@localhost:1521:XE";
    final static String DB_USER = "gusto";
    final static String DB_PASSWORD = "gusto";

    private Connection oracleClient = null;


    public SessionOracleConnectionBean() {
    }
    @Lock(LockType.READ)
    public Connection getOracleClient(){
        return oracleClient;
    }

    @PostConstruct
    public void init()
    {
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            oracleClient = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
            if(oracleClient != null)
            {
                System.out.println("Oracle Cloud DB Connection is Success!");
                System.out.println("******************************************************");
                //printCustomers(oracleClient);
            }
            else{
                System.out.println("******************************************************");
                System.out.println("Oracle Cloud DB Connection is fail!");
            }
        }catch(Exception eee){
            eee.printStackTrace();
        }

    }
}
